<?php

namespace app\api\controller\v1;

use app\common\controller\Api;
use think\Config;
use app\admin\model\companys\Company as CompanyModel;
use app\admin\model\uapply\Cate as CateModel; 
use app\admin\model\message\Message as MessageModel;
use app\admin\model\log\Userlog as UserlogModel;
use app\admin\model\score\Userscore as UserscoreModel;
use app\admin\model\score\Userscorelist as UserscorelistModel;

class Base extends Api{
     
    //  当前文件夹下的所有接口都需要登录
    /*先设置不登录测试*/
     protected $noNeedLogin = [''];
     
     protected $noNeedRight = ['*'];
     
     
     public function _initialize()
     {
         parent::_initialize();
         Config::set('default_return_type', 'json');
     }
     
     //  根据key获取到公司的id
     public function get_companyid()
     {
         $company_key = $this->request->post('company');
         $company_list = CompanyModel::get(['key' => $company_key]);
         $company_id = $company_list['id'];
         return $company_id;
     }
     //根据用户token 获取当前用户对应的角色
     public function get_role()
     {
         $uid = $this->auth->id;
     }
     
     /**
      *获取当前用户所有可看的应用分类
      * 
      */
     public function get_user_apply_cates()
     {
    
          $cateModel = new CateModel();
          $where['uid'] = $this->auth->id; 
          $where['status'] = 0;
          $catelist = $cateModel->where($where)->select();
          $data ="";
          foreach ($catelist as $key =>$val)
          {
             $data .= $val['apply_cid'].',';
          }
          $data = rtrim($data,',');
          // 1,2,3
          return $data;
     }
     
     /**
      *生成日志操作日志 
      * 谁 uid 做了什么事 value
      */
      public function setlog($value = '',$key = '')
      {
          $UserModel = new UserlogModel();
          $UserModel->uid = $this->auth->id;
          $UserModel->createtime = time();
          $UserModel->value = $value;
          $UserModel->key = $key;
          $UserModel->save();
      }
      
      //积分插入
      public function addscore()
      {
          /**
           * 积分插入要分两步骤 1 要先插入到列表中,2再插入到积分表中算总分
           */
           $uid = $this->auth->id;
           
           
           
      }
      
      
     /**
      *查看当前用户用户能否编辑应用分类
      * 
      */
       /**
      *查看当前用户用户能否编辑应用
      * 
      */
       /**
      *查看当前用户用户能否编辑应用结构
      * 
      */
       /**
      *查看当前用户用户能否编辑应用文件
      * 
      */
      /**
       * 创建消息通知
       * 参数(uid,muid,value,type,table_id,company_id)
       * 参数(谁通知的,通知谁,通知内容,通知类型,表单id,公司id)
       * 通知内容 = 显示给用户看的内容
       * 通知类型 0 系统消息, 1 待处理通知 ,2 已开工通知,3 公司通知 4个人通知 5部门通知
       */ 
    //  public function create_Message($uid,$value,)
    //  {
    //     $messagemodel = new MessageModel();
    //      dump($messagemodel);die;
    //  }
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
}