<?php

namespace app\api\controller\v1;


class Qrcode extends Base{
    
    
    protected $noNeedLogin = ['*'];
    
    public function get()
    {
        
        
    }
}