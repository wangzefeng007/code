<?php

namespace app\api\controller\v1;

use app\admin\model\apply\Images as ImagesModel;
use app\admin\model\apply\Category as CategoryModel;

class Apply extends Base
{
    
    //图库
    public function images()
    {
        $where['type_status']  = 1;
        $imagemodel = new ImagesModel();
        $list =  $imagemodel
            ->where($where)
            ->select();
        $apply_images =[];
        foreach ($list as $item => $value)
        {
            $apply_images[$item]['image_path'] = cdnurl($value['local_path_image'],true);
        }
        $data[] = $apply_images;
        $this->success(__('success'), $data);
    }
    
    public  function get_apply_cate()
    {
        $company_id = $this->get_companyid();
        
        $category =  new CategoryModel;
        $company_list = $category->where('company_id',$company_id)
        ->order('weigh', 'desc')
        ->select();
        $data['category'] = $company_list;
        $this->success(__('success'), $data);
    }
    //创建应用分类
    public function set_apply_cate()
    {
        //获取当前公司id
        $company_id = $this->get_companyid();
        // 获取当前分类名
        $cate_name = $this->request->post('cate_name');
        if (empty($cate_name)) {
            $this->error(__('名称不能为空'));
        }
        $weigh = $this->request->post('weigh');
        // dump($weigh);die;
        if (empty($weigh) && $weigh < 0) {
          $weigh = 1;
        }
        // 验证当前公司是否已经有这个名称了 如果重复就不能添加 
        if(!$this->get_cate_name($cate_name,$company_id))
        {
             $this->error(__('当前名称已存在'));
        }
        $category =  new CategoryModel;
        $category->cate_name = $cate_name;
        $category->company_id = $company_id;
        $category->weigh = intval($weigh);
        $isok = $category->save();
        if($isok)
        {
            $this->success(__('创建成功'));
        }
         $this->error(__('当前名称已存在'));
    }
    /**
     *判断当前的应用是否重复 
     */
    public function get_cate_name($cate_name,$company_id)
    {
        $category =  new CategoryModel;
        $where['company_id'] = $company_id;
        $where['cate_name'] = $cate_name;
        $company_list = $category->where($where)->find();
        if (empty($company_list)) {
           return true;
        }
        return false;
    }
    
    
    
}