<?php

namespace app\api\controller\v1;

use app\common\controller\Api;
use think\Config;
use app\admin\model\companys\Company as CompanyModel;
class Base extends Api{
     
    //  当前文件夹下的所有接口都需要登录
     protected $noNeedLogin = [];
     
     protected $noNeedRight = ['*'];
     
     
     public function _initialize()
     {
         parent::_initialize();
         Config::set('default_return_type', 'json');
     }
     
     //  根据key获取到公司的id
     public function get_companyid()
     {
         $company_key = $this->request->post('company');
         $company_list = CompanyModel::get(['key' => $company_key]);
         $company_id = $company_list['id'];
         return $company_id;
     }
     
}