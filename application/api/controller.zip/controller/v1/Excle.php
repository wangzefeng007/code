<?php

namespace app\api\controller\v1; 
use app\admin\model\score\Userscore as UserscoreModel;
use app\admin\model\score\Userscorelist as UserscorelistModel;
use think\Validate; 

class Excle  extends Base{
    
    // from表单随机码
    public function randtablekey()
    {
      $key =  md5(md5(md5(time())) + rand(1,9999));
      $table_name ='fa_s_table_form_'.$key;
      return $table_name;
    }
    
    public function spread_index()
    {
      $rowtable = $this->request->post('rowtable','');
      $rowfrom  = $this->request->post('rowfrom','');
      $rowform_value =  $this->request->post('rowform_value','');
      $rowfromlength = $this->request->post('rowfromlength','');
    //   dump(empty($rowform_value) && empty(trim($rowtable)) && empty(trim($rowfrom))); 
      if (empty($rowform_value) || empty(trim($rowtable))  || empty(trim($rowfrom)) ||  empty(trim($rowfromlength))) {
        $this->error('请选择数据');
      } 
      $table_name =  $this->randtablekey();
      dump($data);die;
    }
    //  将原表结构解析成数组取data结构
    public function rowtable_data()
    {
        
    }
    
    
    
}