<?php


namespace app\api\controller\v1;

use app\BaseController;
use think\Db;


/**
 * 表单目录树
 */
class Formtree extends Base
{
    function getChild($data, $id = 17,$cengji = 0)

    {
        $cengji++;
        $child = array();

        foreach ($data as $key => $datum) {

            if ($datum['pid'] == $id) {

                $datum['key'] = $datum['id'];
                $datum['cengji'] = $cengji;
                if($cengji<3){
                    $datum['children'] = $this->getChild($data, $datum['id'],$cengji);
                }else if($cengji == 3 && $datum['sureform'] == 3 ){
//
                    $inf = Db::name('form_list')->field('id,name as title')->where('category_pid',$datum['id'])->where('is_release',1)->select()->toArray();
                    foreach ($inf as $k => $v){
                        $inf[$k]['key'] = '00'.$inf[$k]['id'];
                    }
                    $datum['children'] = $inf;
                }

                $child[] = $datum;
                unset($data[$key]);

//                $n= $this->getChild($data, $datum['id']);
//                array_push($datum['children'],$n);
//               $child[$datum['id']]['children'] = $this->getChild($data, $datum['id']);

            }

        }

        return $child;

    }
    public function getTree(){
        $inf = Db::name('category')->field('id,pid,name as title,sureform')->where('type','project')->where('pid','<>',0)->select()->toArray();
        $inf = $this->getChild($inf);
//        $inf = json_encode($inf);
//        dump($inf);
        return returnSuccessMsg(1,"成功",$inf);
    }
	public function getlist(){
		$tree = $this->request->post('tree');
		dump($tree);
	}

}