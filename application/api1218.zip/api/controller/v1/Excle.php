<?php

namespace app\api\controller\v1; 
use app\admin\model\score\Userscore as UserscoreModel;
use app\admin\model\score\Userscorelist as UserscorelistModel;
use app\admin\model\diytable\Conventionalmother as ConventionalmotherModel;
use think\Validate; 
use think\Db;
class Excle  extends Base{
     
     
  
     
    // 测试插入数据库的
    public function ss()
    {
        $tablename = 'fa_aaa_aa';
        $data[0] = array(
            'key'=>'pri',
            'type'=>'int',
            'name'=>'id',
            'comment'=>'',
            'default'=>''
            );
             $data[1] = array(
            'key'=>'',    
            'type'=>'varchar',
            'name'=>'name',
            'comment'=>'',
            'default'=>''
            );
            dump($data);die;
        $this->set_table_($tablename);
    }
    
    // from表单随机码
    public function randtablekey()
    {
      $key =  md5(md5(md5(time())) + rand(1,9999));
      $table_name ='fa_s_diy_table_conventional'.$key;
      return $table_name;
    }
    
    public function spread_index()
    { 
     
        //原表数据
      $rowtable = $this->request->post('rowtable','');
      // 表头
      $rowfrom  = $this->request->post('rowfrom','');
      //表头区域
      $rowform_value =  $this->request->post('rowform_value',''); //行索引 从0开始、列索引 从0开始、行数、列数
      //需要填写长度
      $rowfromlength = $this->request->post('rowfromlength','');
      
    //   表单填写在表格的位置
      $formbody = $this->request->post('formbody','');
      if (empty($rowform_value) || empty(trim($rowtable))  || empty(trim($rowfrom)) ||  empty(trim($rowfromlength))) {
        $this->error('请选择数据');
      }  
      $rowfrom_array =  $this->rowfrom($rowfrom);
      $rowform_value_array = $this->rowform_value($rowform_value);
      $formbody_array = $this->formbody($formbody); 
      $rowfromlength_int_value = $this->rowfromlength($rowfromlength,$formbody_array['rowCount']);
    //   dump($rowfromlength_int_value);die;
      list($rowtable_data_datatable_all_array,$rowtable_spans_all_array) = $this->rowtable($rowtable);
    // 表单高度 如果大于1 说明有父级存在
      $form_rowCount = $rowform_value_array['rowCount'];
      $form_row = $rowform_value_array['row'];
      //本身也是一个身高
      $form_sum_heigh = $form_row + $form_rowCount - 1;
    //   $suspected_father = [];
      $all_list = []; //当前表单位置的数组集合  用来查找对应的值 在哪个数组上
    //查看数据存在哪个数组中是在哪个位置
      for($i = $form_row ;$i <= $form_sum_heigh ; $i++)
        {
           $all_list[$i] =  $rowtable_data_datatable_all_array[$i];
        }
    // dump($all_list);die;
    // $col_value_ 获取有值的form表单的坐标轴
    //除了坐标轴外要把其他的数据也给拿到防止丢失
    list($col_value_,$col_value_all) = $this->search_array_col_row($all_list);
    // 当前表单总合并项$spans_form_array
    //当前无父级也就是上下合并一起的 suspected_father
    //还处于无序的 notsuspected_father
    list($spans_form_array,$suspected_father,$not_suspected_father) = $this->rowtable_spans_all_array($rowtable_spans_all_array,$form_row,$form_rowCount);
     // 提取表单填写区域 因为有些已经是默认值了 所以需要把默认值提取出来
     $formbody_value_array =   $this->formbody_array($rowtable_data_datatable_all_array,$formbody_array);
    // 排移动端表单展示的顺序
     $list = $this->create_form_($spans_form_array,$all_list,$form_row,$form_rowCount,$formbody_array['row']);
    //  取填写表单相邻的的数据 并diy 
    $filed_arr = []; //这个是为创建数据库表字段使用的
    $filed_data = [];
    foreach ($list as $lk => $lv)
    {
        // dump($lv);die;
        if($lv['rowCount'] +$lv['row'] == $formbody_array['row'] )
        {
            // 生成随机值 当做diy表字段 并写入
            $filed = $this->rand_filed($lv);
            $lv['filed'] = $filed;
            $filed_data[] = $lv;
            //这个key是字段名
            $filed_arr[$lk]['key'] = $filed;
            //这个value是字段注释
            
            if($lv['pid'] == 0)
            {
                $filed_arr[$lk]['value_all'] = '['.$lv['value'].']';
            }else
            {
                $name = $this->find_f_name($list,$lv['pid']);
                $filed_arr[$lk]['value_all'] = $name.'['.$lv['value'].']';
            }
             $filed_arr[$lk]['id'] = $lv['id'];
             $filed_arr[$lk]['pid'] = $lv['pid'];
             $filed_arr[$lk]['colCount'] = $lv['colCount'];
             $filed_arr[$lk]['rowCount'] = $lv['rowCount'];
             $filed_arr[$lk]['col'] = $lv['col'];
             $filed_arr[$lk]['row'] = $lv['row'];
             $filed_arr[$lk]['value'] = $lv['value'];
            // dump($lv);
           
        }
        
    }
    $filed_arr = array_values($filed_arr);
    // die;
    // 生成diy表名
    // dump($this->auth->id);die;
    $table_name = $this->randtablekey();
    $datadata['table_key'] =  $table_name;
    $datadata['table_value'] =  '记录表';
    $datadata['table_top_original'] =  '头部原数据';
    $datadata['table_all_original'] =  $rowtable;
    $datadata['table_form_top_original'] =  $rowfrom;
    $datadata['table_form_row_one'] =  $formbody;
    $datadata['table_form_col_one'] =  $rowfromlength;
    $datadata['set_num'] =  $rowfromlength_int_value;
    $datadata['table_field_value'] =  json_encode($filed_arr);
    $this->save_diy_table($datadata);
    // 把数据保存到数据库并diy生成表
     
    }
    public function save_diy_table($data)
    {
           $table_name = $data['table_key'];
           $parma = json_decode($data['table_field_value'],true);
           $str = '';
           $str .= "`id` int(11) unsigned NOT NULL AUTO_INCREMENT,";
           $str .= "`status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '状态',";
           $str .= "`table_top` varchar(255)  DEFAULT '' COMMENT '对应的顶部表头表',";
           $str .= "`uid` int(10) UNSIGNED  DEFAULT '0' COMMENT '填写者',";
           $str .= "`createtime` int(11) UNSIGNED  DEFAULT '0' COMMENT '创建时间',";
           $str .= "`updatetime` int(11) UNSIGNED  DEFAULT '0' COMMENT '修改时间',";
           $str .= "`deletetime` int(11) UNSIGNED  DEFAULT '0' COMMENT '删除时间',";
           foreach ($parma as $key => $value)
           {
               $str .= "`".$value['key']."` varchar(255)  DEFAULT '' COMMENT "."'".$value['value_all']."'," ;
           }
           $str .= 'PRIMARY KEY (`id`)';
            Db::startTrans();
            try {
                // 第一步先建表 
                $sql = "CREATE TABLE $table_name ($str) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT";
                // dump($sql);die;
		      	Db::execute($sql);
                // 第二步再保存
                $conventionalmotherModel  = new ConventionalmotherModel;
                // 暂时先放这个
                $conventionalmotherModel->uid = $this->auth->id;
                $conventionalmotherModel->table_key = $table_name;
                $conventionalmotherModel->table_value = $data['table_value'];
                $conventionalmotherModel->table_top_original = $data['table_top_original'];
                $conventionalmotherModel->table_all_original = $data['table_all_original'];
                $conventionalmotherModel->table_form_top_original = $data['table_form_top_original'];
                $conventionalmotherModel->table_form_row_one = $data['table_form_row_one'];
                $conventionalmotherModel->table_form_col_one = $data['table_form_col_one'];
                $conventionalmotherModel->set_num = $data['set_num']; 
                $conventionalmotherModel->table_field_value = $data['table_field_value'];
                $conventionalmotherModel->createtime = time();
                $conventionalmotherModel->save();
                Db::commit();
                $this->success('创建成功');
            }
            catch (Exception $e) {
              Db::rollback();
              return $e->getMessage();
            }
            
      
      
      
    }
    // 递归找爸爸名字
    public function find_f_name($data,$pid)
    {
        
        static $f_name = '';   // 定义存储子级数据数组
        
        foreach ($data as $k => $v)
        { 
            if($v['id'] == $pid)
            {
                $f_name = '['.$v['value'].']';
                unset($data[$k]);
                $this->find_f_name($data,$v['pid']);
            }
        }
        
        return $f_name;
       
    }
    public function rand_filed($data)
    {
      $field = 'key'. md5(base64_encode(json_encode($data)));
      return $field;
    }
    public function formbody_array($data,$formbody_array)
    {
        // dump(3);die;
        $datas = [];
        for($i = $formbody_array['row'];$i < $formbody_array['row'] + $formbody_array['rowCount']  ; $i++)
        { 
           
            foreach ($data[$i] as $key =>  $value)
            {
                if(isset($value['value']))
                {
                    $value['kkk_row'] = $i;
                    $value['kkk_col'] = $key; 
                    $datas[] = $value;
                }
               
            }
        } 
        return $datas;
    }
    // 排移动端表单展示的顺序 $h  当前表单的初始位置
    public function create_form_($spans_form_array,$all_list,$form_row,$form_rowCount,$h)
    {
        // dump($spans_form_array);
        // dump($all_list);
        // dump($form_row);
        // dump($form_rowCount);
        // die;
        $form_list = [];
        // 获取第一个值
        // $first_value = $all_list[$form_row][0]['value'];
        $daa = [];
        $dat = [];
        foreach ($all_list as $keys => $values)
        {
            foreach ($values as $key=>$value)
            {
               
                //判断是否有值存在 如果有就去查合并
                if(isset($value['value']))
                {
                   foreach($spans_form_array as $ke => $val)
                   { 
                    //   dump($spans_form_array);die;
                    //   查找当前所在行列 是否有合并项 如果有存在 那就两种可能 一种是行高会等于选中的原行高 有一种是小于原行高 说明有子级存在
                      if($val['row'] == $keys && $val['col'] == $key)
                      {
                          $value['colCount'] = $val['colCount'];
                          $value['rowCount'] = $val['rowCount'];
                          $value['col'] = $val['col'];
                          $value['row'] = $val['row'];
                      }
                   }
                    
                    $value['keys'] = $keys;
                    $value['key'] = $key;
                    $daa[] = $value;
                }
               
            }
            
        }
       foreach ($daa as $pk =>$pv)
       {
           if(!isset($pv['col']))
           {
               $pv['col'] = $pv['key'];
               $pv['row'] = $pv['keys'];
               $pv['colCount'] = 1;
               $pv['rowCount'] = 1;
               
           }
           $dasa[] =  $pv;
       }
      $dat = $this->setpid($dasa,$form_row,$h);
    //   $dat_json = json_encode($dat);   
    //   $pid_0 = [];
    //   $tree = [];
    //   foreach ($dat as $gk=>$gv)
    //   {
    //       if($gv['pid']==0)
    //       {
    //           $pid_0[] = $gv;
    //       }
    //   }
    //   foreach ($pid_0 as $fk => $fv)
    //   {
    //       foreach ($dat as $kk=>$vv)
    //       {
    //           if($vv['pid'] == $fv['id'])
    //           {
    //               $pid_0['son'][] = $vv;
    //           }
    //       }
    //   }
    //   dump($pid_0);die;
      return $dat;
        
       
    }
    
 
    //设置pid
    // $da = [];
    public function setpid($data,$row,$h)
    {
        // 设置父id的常量标识当前为id
        // 表头总高度
        // dump($data);die; 
        $height = $h - $row;
        // 找祖宗 并且设置pid = 0;且设置id值
        foreach($data as $key => $value)
        {   
            $i = 1;
            if($value['row'] ==  $row)
            {
                $value['pid'] = 0;
                $value['id'] = $key+1;
                // pid = 0 时候
                $dapid[] = $value;
            }
            else{
                // pid != 0 的数据
                $da[] = $value;
            }
            
        }
        // 找儿子
        $dde = [];
        $dda = [];
        $ddh = [];
        foreach($dapid as $lk => $lv)
        {
            // dump($lv);die;
            // 如果等于rowCount 会等于表头高度说明这个数据 没有儿子 不等于 就是有儿子w
            if($lv['rowCount'] != $height)
            {
                // 开始找儿子
                foreach($da as $dk => $dv)
                { 
                    // 第一步  先获取到 父亲所在的列
                    $p_col = $lv['col'];
                
                    // 第二 步查看父亲所占的列有几格
                    $p_col_count = $lv['colCount'];  
                    // 第三步 查看备选的儿子中哪个是属于这里面的
                    if($dv['col'] >= $p_col && $dv['col'] <= $p_col + $p_col_count -1)
                    {
                    //   查看相连的两个
                       if($dv['row'] == $lv['row']+$lv['rowCount'])
                       {
                            $dv['pid'] = $lv['id'];
                            $dv['id'] = count($dapid) + $dk + 1 ;
                            // 儿子
                            $dd[] = $dv;
                       }else{
                        //   孙子
                           $dde[] =  $dv;
                       }
                           
                    }
                    
                }
               
            }
         
        }
        // dump($dd);die;
        //找儿子的儿子  
        $ids = 1000;
        foreach($dd as $lk => $lv)
        {
            // 如果等于rowCount 会等于表头高度说明这个数据 没有儿子 不等于 就是有儿子w
            if($lv['rowCount'] != $height)
            {
                // 开始找儿子
                foreach($dde as $dk => $dv)
                { 
                    // 第一步  先获取到 父亲所在的列
                    $p_col = $lv['col'];
                
                    // 第二 步查看父亲所占的列有几格
                    $p_col_count = $lv['colCount'];  
                    // 第三步 查看备选的儿子中哪个是属于这里面的
                    if($dv['col'] >= $p_col && $dv['col'] <= $p_col + $p_col_count -1)
                    {
                    //   查看相连的两个
                       if($dv['row'] == $lv['row']+$lv['rowCount'])
                       {
                            $dv['pid'] = $lv['id'];
                            $dv['id'] = $ids + $dk;
                            // 儿子
                            $dda[] = $dv;
                       }else{
                        //   孙子
                           $ddb[] =  $dv;
                       }
                           
                    }
                    
                }
               
            }
         
        }
        //找儿子的儿子的儿子
        $ddj = [];
         foreach($dda as $lk => $lv)
        {
            // 如果等于rowCount 会等于表头高度说明这个数据 没有儿子 不等于 就是有儿子w
            if($lv['rowCount'] != $height)
            {
                // 开始找儿子
                foreach($ddb as $dk => $dv)
                { 
                    // 第一步  先获取到 父亲所在的列
                    $p_col = $lv['col'];
                
                    // 第二 步查看父亲所占的列有几格
                    $p_col_count = $lv['colCount'];  
                    // 第三步 查看备选的儿子中哪个是属于这里面的
                    if($dv['col'] >= $p_col && $dv['col'] <= $p_col + $p_col_count -1)
                    {
                    //   查看相连的两个
                       if($dv['row'] == $lv['row']+$lv['rowCount'])
                       {
                            $dv['pid'] = $lv['id'];
                            $dv['id'] = $ids*10 + $dk;
                            // 儿子
                            $ddh[] = $dv;
                       }else{
                        //   孙子
                           $ddj[] =  $dv;
                       }
                           
                    }
                    
                }
               
            }
         
        }
        // dump($ddj);die;
        //当前处理为四级  如果有需要再复制一份循环
        if(!empty($ddj))
        {
            $this->error('表单不能超过4级,如果有需要联系管理员');
        }
        $result = array_merge($dapid,$dd,$dda,$ddh);
        return $result;
    }
   
    // 根据二维数组获取对应value有值的坐标
    public function search_array_col_row($data)
    {
      
        // 判断当前数组是否是二维数组
        // if($data)
        $result = [];
        $array = [];
        foreach ($data as $key=>$value)
        {
            foreach ($value as $k=>$v)
            {
                
                if(isset($v['value']))
                {
                    $result[$key.','.$k] = $v['value'];
                    $array[$key.','.$k] = $v;
                }
            }
             
        }
        
        return array($result,$array);
    }
    //获取当前表单合并信息
    /**
     *$data 当前所有合并数 
     *$row 当前表单内容的启示位置
     *$rowCount 有几行
     */
    public function rowtable_spans_all_array($data = '',$row = '',$rowCount = '')
    {
        $rowCount_rowCount = [];
        $donotrowCount_rowCount = []; 
        $result = [];
        $form_sum_heigh = $row + $rowCount -1 ;
        //对应表单内容所有的合并
        for($i = $row ;$i <= $form_sum_heigh ; $i++)
        { 
            foreach ($data as $key=>$value)
            {
                 if($value['row'] == $i)
                 {
                     $result[] = $value;
                  //把当前行高等于合并高度的提取出来 这个是无父级的合并项
                 if($value['rowCount'] == $rowCount)
                  {
                     $rowCount_rowCount[] = $value;
                  }
                  //把其他不是同一个的另存一份
                  else
                  {
                      $donot_rowCount_rowCount[] = $value;
                  }
                 }
                 
            }
        }
        
      return array($result,$rowCount_rowCount,$donot_rowCount_rowCount);
    }
    public function rowtable($data)
    {
        $data = base64_decode($data);
        $data = gzdecode($data);
        $data = urldecode($data);
        $data = $this->js_unescape($data);
        $data = json_decode($data,true);
        $data = $data['sheets'];
        $dataTable = $data[array_keys($data)[0]]['data']['dataTable'];
        $spans = $data[array_keys($data)[0]]["spans"];
        return array($dataTable,$spans);
    }
    // 解密表单数据
    public function rowfrom($data)
    {
    //   dump($data);die;
      $data = base64_decode($data);
      $data = gzdecode($data);
      $data = urldecode($data);
      $data = $this->js_unescape($data);
      $data = json_decode($data,true);
      $k_num = 0; //查看长度
      $array = [];
      foreach ($data as $key=>$value)
      {
          foreach ($value as $k=>$v)
          {
              $k_num++;
              if($v !== NULL)
              {
                  $array[] = $v;
              }
          }
      }
    return $array;

    }
    //表单所在表格中的坐标轴
    public function rowform_value($data)
    { 
      $data = base64_decode($data);
      $data = json_decode($data,true);
      return $data;
    }
    public function rowfromlength($data,$rowCount)
    {
        $data = base64_decode($data);
        $data = json_decode($data,true);
        //有时候填写的数据可能是两行或者3行 所以这个页面的数据是多少行/一个数据占多少行 =  现在这个页面的数据是多少条
        $rowCount = $data['rowCount']/$rowCount;
        return $rowCount;
    }
    public function formbody($data)
    {
      $data = base64_decode($data);
      $data = json_decode($data,true);
      return $data;
    }
    //  将原表结构解析成数组取data结构 
    public function rowtable_data()
    {
        
    } 
    // 去除选择表单数据中的杂质 只留null和文字和,
    public function impurity($title)
    { 
       
    }
    // 加密中文乱码%u开头
    public function js_unescape($str)
    {
        $ret = '';
        $len = strlen($str);
        for ($i = 0; $i < $len; $i++) 
        {
            if ($str[$i] == '%' && $str[$i+1] == 'u') {
                $val = hexdec(substr($str, $i+2, 4));
                if ($val < 0x7f) $ret .= chr($val);
                else if($val < 0x800) $ret .= chr(0xc0|($val>>6)).chr(0x80|($val&0x3f));
                else $ret .= chr(0xe0|($val>>12)).chr(0x80|(($val>>6)&0x3f)).chr(0x80|($val&0x3f));
                $i += 5;
            }
            else if ($str[$i] == '%') 
            {
                $ret .= urldecode(substr($str, $i, 3));
                $i += 2;
            }
            else {
                $ret .= $str[$i];
            }
        }
        return $ret;
    }
    /**
     * 根据前端获取到的行列索引和长度获取到对应的数据 并把对应的值拿到 并返回该区域的所有值
     * 
     */ 
    /**
     * 根据当前区域获取到父级和子级关系 返回成表单格式
     * 
     */
    /**
      *制作数据库表 根据表单关系设置表结构 
      * 
      */
    /***
       * 
       *创建数据库表  参数1 table_name表名 2data 字段参数 
       */
   public function create_table($table_name,$data = '')
   {
    //   dump($table_name);die;
    //   if(!is_array($data))
    //   {
    //       return false;
    //   }
     
     //查看当前数据库是否存在 如果存在就提示 如果不存在就可以下一个步骤
         $sql =  "select * from information_schema.TABLES where TABLE_NAME = '$table_name'";
         $is_table =  Db::execute($sql);
       //检测当前表名是否存在
      if($is_table)
      { 
          return false;
      }
    //   dump(223);die;
    //   $sql = "CREATA TABLE IF NOT EXISTS '$table_name' ('id' int(10) UNSIGNED NOT NULL AUTO_INCREMENT,'uid' int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '用户id',PRIMARY KEY ('id')) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf-8 COMMENT='测试表'";
        $sql = "CREATE TABLE $table_name ( id int(10) primary key  UNSIGNED NOT NULL AUTO_INCREMENT) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT";
       dump($sql);die;
       $is_table =  Db::execute($sql);
       dump($is_table);die;
   }
    
    
}