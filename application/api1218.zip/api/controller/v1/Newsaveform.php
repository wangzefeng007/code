<?php

namespace app\api\controller\v1;

use app\admin\model\apply\Images as ImagesModel;
use app\admin\model\apply\Category as CategoryModel;
use app\admin\model\apply\Formlist as FormlistModel;
use app\admin\model\apply\Structure as StructureModel;
use app\admin\model\apply\Formstructure as FormstructureModel;
use think\Db;

class Newsaveform extends Base
{
	public function form_save(){
		$Formstructure = new FormstructureModel;
		
		$uid = $this->auth->id;
		$company_id = $this->get_companyid();
		//有就传 没有就传空 文件id
		$structureid = $this->request->post('structureid');
		//json内容
		$form_strstructure  = $_POST['form_strstructure'];
		$form_strstructuredecode = json_decode($form_strstructure,true);
		// dump($form_strstructure);
		//归属应用id
		$apply_id  = $this->request->post('apply_id');
		//表单名称
		$form_name = $this->request->post('form_name');
		//表单层级
		$form_hierarchy = $this->request->post('form_hierarchy');
		
		// if($structureid == 0){
		// 	$in['name'] = $form_name;
		// 	$in['apply_id'] = $apply_id;
		// 	$in['form_hierarchy'] = $form_hierarchy;
		// 	$in['list'] = $form_strstructure;
		// 	// dump($in);
		// 	$informname = Db::name('s_formname')->insert($in);
		// 	// dump($informname);
		// 	$in_id = Db::name('s_formname')->getLastInsID();
		// }else{
			$in['str_name'] = $form_name;
			$in['list'] = $form_strstructure;
			$sure = Db::name('s_apply_structure')->where('id',$structureid)->update($in);
			$in_id = $structureid;
		// }
		$delformlist = Db::name('s_formlist')->where('form_belong',$in_id)->delete();
		foreach($form_strstructuredecode as $key => $val){
			// dump($val);
			$str = 'id int(10) primary key NOT NULL AUTO_INCREMENT';
			$name = "fa_s_form_".$key."_".$val['key'];
			$nname = "s_form_".$key."_".$val['key'];
			$form_key = $val['key'];
			
			
			
			$data['type'] = $val['type'];
			$data['label'] = $val['label'];
			$data['typename'] = $val['typename'];
			$data['formtype'] = $val['formtype'];
			$data['form_hierarchy'] = $form_hierarchy;
			$data['form_key'] = $form_key;
			$data['form_belong'] = $in_id;
			$data['weight'] = $key;
			
			$insertsure = Db::name('s_formlist')->insert($data);
			$array = array();
			$adata = array();
			// dump($val['list']);
			$sql = "DROP TABLE IF EXISTS $name";
			Db::execute($sql);
			
			foreach($val['list'] as $listkey => $listval){
				// dump($listkey);
				// dump($listval);
				$list_key = $listval['key'];
				$list_key_name = $listval['key']."_name";
				$list_key_type = $listval['key']."_type";
				$inf = json_encode($listval);
				$str = $str.", $list_key text,$list_key_name varchar(255),$list_key_type varchar(255)";
				$adata[$listkey]['id'] = NULL;
				$adata[$listkey]['form_name'] = $nname;
				$adata[$listkey][$list_key] = $inf;
				$adata[$listkey][$list_key_name] = $listval['label'];
				$adata[$listkey][$list_key_type] = $listval['type'];
				
				$indata[$listkey]['list_key'] = $list_key;
				$indata[$listkey]['weight'] = $listkey;
				$indata[$listkey]['form_key'] = $form_key;
				$indata[$listkey]['in_id'] = $in_id;
				
			}
			$sql = "CREATE TABLE $name ($str) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT";
			$n = Db::execute($sql);
			foreach($adata as $adatakey => $adataval){
				// dump($adataval);
				$formname = $adataval['form_name'];
				unset($adata[$adatakey]['form_name']);
				$sureinsert = Db::name($formname)->insert($adata[$adatakey]);
			}
			$del_process = Db::name('s_formprocess')->where('form_key',$form_key)->delete();
			// dump($indata);
			foreach($indata as $indatakey => $indataval){
				$insertprocess = Db::name('s_formprocess')->insert($indataval);
			}
		}
		
		$this->success(__('成功'));
	}
	// /* 获取结构下表单列表 */
	// public function formlist_get(){
	// 	//应用id
	// 	$apply_id = $_POST['apply_id'];
	// 	//层级id
	// 	$form_hierarchy = $_POST['form_hierarchy'];
	// 	$inf = Db::name('s_formname')->where('apply_id',$apply_id)->where('form_hierarchy',$form_hierarchy)->select();
	// 	$this->success(__('成功'),$inf);
	// }
	
	public function form_get(){
		
		$structureid = isset($_POST['structureid']) ? $_POST['structureid'] : '2';
		
		$inf = Db::name('s_apply_structure')->where('id',$structureid)->find();
		
		$last = $inf['list'];
		$last = \json_decode($last);
		// $data['list'] = $last;
		// $data['name'] = $inf['str_name'];
		// dump($last);
		$this->success(__('成功'),$last);
	}
	
}