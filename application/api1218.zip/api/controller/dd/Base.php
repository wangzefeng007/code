<?php

namespace app\api\controller\dd;
use app\common\controller\Api;
use think\Config;
use app\admin\model\companys\Company as CompanyModel;
use app\admin\model\uapply\Cate as CateModel; 
use app\admin\model\message\Message as MessageModel;
use app\admin\model\log\Userlog as UserlogModel;
use app\admin\model\score\Userscore as UserscoreModel;
use app\admin\model\score\Userscorelist as UserscorelistModel;
use think\Db;
class Base extends Api{   
    //  当前文件夹下的所有接口都需要登录
    /*先设置不登录测试*/
     protected $noNeedLogin = ['*'];
     
     protected $noNeedRight = ['*'];
     
      public function _initialize()
     {
         parent::_initialize();
         Config::set('default_return_type', 'json');
     }
     //  根据key获取到公司的id
     public function get_companyid()
     {
         $company_key = $this->request->post('company');
         $company_list = CompanyModel::get(['key' => $company_key]);
         $company_id = $company_list['id'];
         return $company_id;
     }
     /**
      *生成日志操作日志 
      * 谁 uid 做了什么事 value
      */
      public function setlog($value = '',$key = '')
      {
          $UserModel = new UserlogModel();
          $UserModel->uid = $this->auth->id;
          $UserModel->createtime = time();
          $UserModel->value = $value;
          $UserModel->key = $key;
          $UserModel->save();
      }
}
     