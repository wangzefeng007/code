<?php
namespace app\api\controller\dd;

use app\common\model\User;

class Index extends Base

{
    // 根据手机号获取token
    
    protected $noNeedLogin = ['get_token'];
    
    public function get_token()
    {
        //获取手机号码
        $mobile = $this->request->post('mobile','');
        if (empty($mobile)) {
            $this->error('手机号不能为空');
        }
        //根据手机号码获取到用户id
        $usermodel =  new User;
        $where['mobile'] = $mobile;
        $userlist  =$usermodel->field('id')->where($where)->find();
        $uid = $userlist['id'];
        $data['id'] = $uid;
        $this->success(__('success'), $data);
        
    }
}
