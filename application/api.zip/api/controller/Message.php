<?php

namespace app\api\controller;

use app\common\controller\Api;

class Message extends Api{
    
    public function index()
    {
        dump(1);die;
    }
    
}