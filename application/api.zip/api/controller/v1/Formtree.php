<?php


namespace app\api\controller\v1;

use app\admin\model\apply\Strlist as StrlistModel;
use app\admin\model\apply\Structure as StructureModel;
use app\BaseController;
use think\Db;


/**
 * 表单目录树
 */
class Formtree extends Base
{
    function getChild($data, $id = 17,$cengji = 0)

    {
        $cengji++;
        $child = array();

        foreach ($data as $key => $datum) {

            if ($datum['pid'] == $id) {

                $datum['key'] = $datum['id'];
                $datum['cengji'] = $cengji;
                if($cengji<3){
                    $datum['children'] = $this->getChild($data, $datum['id'],$cengji);
                }else if($cengji == 3 && $datum['sureform'] == 3 ){
//
                    $inf = Db::name('form_list')->field('id,name as title')->where('category_pid',$datum['id'])->where('is_release',1)->select()->toArray();
                    foreach ($inf as $k => $v){
                        $inf[$k]['key'] = '00'.$inf[$k]['id'];
                    }
                    $datum['children'] = $inf;
                }

                $child[] = $datum;
                unset($data[$key]);

//                $n= $this->getChild($data, $datum['id']);
//                array_push($datum['children'],$n);
//               $child[$datum['id']]['children'] = $this->getChild($data, $datum['id']);

            }

        }

        return $child;

    }
    public function getTree(){  
        $inf = Db::name('category')->field('id,pid,name as title,sureform')->where('type','project')->where('pid','<>',0)->select()->toArray();
        $inf = $this->getChild($inf);
//        $inf = json_encode($inf);
//        dump($inf);
        return returnSuccessMsg(1,"成功",$inf);
    }
	public function getlist(){
		$tree = $this->request->post('tree');
		dump($tree);
	}
	
	public function save_tree_node(){
		
		$strlist = new StrlistModel;
		$structure = new StructureModel;
		
		//获取用户id
		$u_id = $this->auth->id;
		//获取当前公司id
		$company_id = $this->get_companyid();
		//父级id
		$pid = $this->request->post('pid');
		//应用id
		$apply_id = $this->request->post('apply_id');
		//应用名称
		$str_name = $this->request->post('str_name');
		//如果是第一层 添加到strlist
		if($pid == 0){
			$structure->apply_id = $apply_id;
			$structure->u_id = $u_id;
			$structure->str_name = $str_name;
			$structure->company_id = $company_id;
			$structure->createtime = time();
			$structure->str_pid = 0;
			$structure->save();
			$str_id = $structure->id;
			
			$strlist->apply_id = $apply_id;
			$strlist->structure_id = $str_id;
			$strlist->save();
			$lastinf = $this->get_tree_list($company_id);
			$this->success(__('创建成功'),$lastinf);
		//如果不是第一层 
		}else{
			$structure->apply_id = $apply_id;
			$structure->u_id = $u_id;
			$structure->str_name = $str_name;
			$structure->company_id = $company_id;
			$structure->createtime = time();
			$structure->str_pid = 0;
			$structure->save();
			$lastinf = $this->get_tree_list($company_id);
			$this->success(__('创建成功'),$lastinf);
		}
	}
	public function get_tree_list($company_id){
		
		$strlist = new StrlistModel;
		
		$inf = $strlist->where('company_id',$company_id)->toArray();
		return $inf;
	}
}