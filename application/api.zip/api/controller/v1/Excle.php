<?php

namespace app\api\controller\v1; 
use app\admin\model\score\Userscore as UserscoreModel;
use app\admin\model\score\Userscorelist as UserscorelistModel;
use think\Validate; 
use think\Db;
class Excle  extends Base{
    
     
    // from表单随机码
    public function randtablekey()
    {
      $key =  md5(md5(md5(time())) + rand(1,9999));
      $table_name ='fa_s_table_form_'.$key;
      return $table_name;
    }
    
    public function spread_index()
    { 
        //原表数据
      $rowtable = $this->request->post('rowtable','');
      // 表头
      $rowfrom  = $this->request->post('rowfrom','');
      //表头区域
      $rowform_value =  $this->request->post('rowform_value',''); //行索引 从0开始、列索引 从0开始、行数、列数
      //需要填写长度
      $rowfromlength = $this->request->post('rowfromlength','');
    //   表单填写在表格的位置
      $formbody = $this->request->post('formbody','');
      if (empty($rowform_value) || empty(trim($rowtable))  || empty(trim($rowfrom)) ||  empty(trim($rowfromlength))) {
        $this->error('请选择数据');
      }  
      $rowfrom_array =  $this->rowfrom($rowfrom);
      $rowform_value_array = $this->rowform_value($rowform_value);
      $formbody_array = $this->formbody($formbody);
      $rowfromlength_int_value = $this->rowfromlength($rowfromlength,$formbody_array['rowCount']);
      list($rowtable_data_datatable_all_array,$rowtable_spans_all_array) = $this->rowtable($rowtable);
    // 表单高度 如果大于1 说明有父级存在
      $form_rowCount = $rowform_value_array['rowCount'];
      $form_row = $rowform_value_array['row'];
      $form_sum_heigh = $form_row + $form_rowCount;
      $suspected_father = [];
      $all_list = []; //当前表单位置的数组集合  用来查找对应的值 在哪个数组上
    //查看数据存在哪个数组中是在哪个位置
      for($i = $form_row ;$i <= $form_sum_heigh ; $i++)
        {
           $all_list[$i] =  $rowtable_data_datatable_all_array[$i];
        }
        /**
         * 查看数据存在二维数组数组中是在哪个位置
         */ 
      foreach ($rowfrom_array as $key => $value)
      {
        foreach ($all_list as $kk=>$vv)
        {
            foreach ($vv as $kkk=>$vvv)
            {
                 $data = array_search($value,$vvv);
                 dump($data);die;
            }
            // dump($value);dump($vv);die;
         
          dump($data);die;
        }
        // $data = array_search($value,$all_list);
        //   dump($data);die;
      }
        
        
        dump($rowform_value_array);die;
    //   foreach ($rowform_value_array as $value)
      dump($rowform_value_array);die;
      
      
      dump($rowtable_data_datatable_all_array);
      dump($rowtable_spans_all_array);
      die;
      //生成随机表名
      $table_name =  $this->randtablekey(); 
      dump($rowtable);  dump($rowfrom);  dump($rowform_value);  dump($rowfromlength);die;
    }
    public function rowtable($data)
    {
        $data = base64_decode($data);
        $data = gzdecode($data);
        $data = urldecode($data);
        $data = $this->js_unescape($data);
        $data = json_decode($data,true);
        $data = $data['sheets'];
        $dataTable = $data[array_keys($data)[0]]['data']['dataTable'];
        $spans = $data[array_keys($data)[0]]["spans"];
        return array($dataTable,$spans);
    }
    // 解密表单数据
    public function rowfrom($data)
    {
    //   dump($data);die;
      $data = base64_decode($data);
      $data = gzdecode($data);
      $data = urldecode($data);
      $data = $this->js_unescape($data);
      $data = json_decode($data,true);
      $k_num = 0; //查看长度
      $array = [];
      foreach ($data as $key=>$value)
      {
          foreach ($value as $k=>$v)
          {
              $k_num++;
              if($v !== NULL)
              {
                  $array[] = $v;
              }
          }
      }
    return $array;

    }
    //表单所在表格中的坐标轴
    public function rowform_value($data)
    { 
      $data = base64_decode($data);
      $data = json_decode($data,true);
      return $data;
    }
    public function rowfromlength($data,$rowCount)
    {
        $data = base64_decode($data);
        $data = json_decode($data,true);
        //有时候填写的数据可能是两行或者3行 所以这个页面的数据是多少行/一个数据占多少行 =  现在这个页面的数据是多少条
        $rowCount = $data['rowCount']/$rowCount;
        return $rowCount;
    }
    public function formbody($data)
    {
      $data = base64_decode($data);
      $data = json_decode($data,true);
      return $data;
    }
    
    
    
    
    //  将原表结构解析成数组取data结构 
    public function rowtable_data()
    {
        
    } 
    // 去除选择表单数据中的杂质 只留null和文字和,
    public function impurity($title)
    { 
       
    }
    // 加密中文乱码%u开头
    public function js_unescape($str)
    {
        $ret = '';
        $len = strlen($str);
        for ($i = 0; $i < $len; $i++) 
        {
            if ($str[$i] == '%' && $str[$i+1] == 'u') {
                $val = hexdec(substr($str, $i+2, 4));
                if ($val < 0x7f) $ret .= chr($val);
                else if($val < 0x800) $ret .= chr(0xc0|($val>>6)).chr(0x80|($val&0x3f));
                else $ret .= chr(0xe0|($val>>12)).chr(0x80|(($val>>6)&0x3f)).chr(0x80|($val&0x3f));
                $i += 5;
            }
            else if ($str[$i] == '%') 
            {
                $ret .= urldecode(substr($str, $i, 3));
                $i += 2;
            }
            else {
                $ret .= $str[$i];
            }
        }
        return $ret;
    }
    /**
     * 根据前端获取到的行列索引和长度获取到对应的数据 并把对应的值拿到 并返回该区域的所有值
     * 
     */ 
    /**
     * 根据当前区域获取到父级和子级关系 返回成表单格式
     * 
     */ 
     /**
      *制作数据库表 根据表单关系设置表结构 
      * 
      */
      /***
       * 
       *创建数据库表  参数1 table_name表名 2data 字段参数 
       */
   public function create_table($table_name,$data = '')
   {
    //   dump($table_name);die;
    //   if(!is_array($data))
    //   {
    //       return false;
    //   }
     
     //查看当前数据库是否存在 如果存在就提示 如果不存在就可以下一个步骤
         $sql =  "select * from information_schema.TABLES where TABLE_NAME = '$table_name'";
         $is_table =  Db::execute($sql);
       //检测当前表名是否存在
      if($is_table)
      { 
          return false;
      }
    //   dump(223);die;
    //   $sql = "CREATA TABLE IF NOT EXISTS '$table_name' ('id' int(10) UNSIGNED NOT NULL AUTO_INCREMENT,'uid' int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '用户id',PRIMARY KEY ('id')) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf-8 COMMENT='测试表'";
        $sql = "CREATE TABLE $table_name ( id int(10) primary key  UNSIGNED NOT NULL AUTO_INCREMENT) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT";
       dump($sql);die;
       $is_table =  Db::execute($sql);
       dump($is_table);die;
   }
    
    
}